/* =========================================================
   CRIMSON — shared site behaviour (loaded on every page)
   - header "scrolled" state
   - mobile menu open / close (button, link click, Escape)
   - animated background particles (only where #particles exists)
   Page-specific scripts must NOT redeclare these behaviours.
   ========================================================= */
(function(){
  'use strict';

  /* ---------- Header scroll state ---------- */
  const header = document.getElementById('siteHeader') || document.querySelector('header');
  if(header){
    const onScroll = ()=> header.classList.toggle('scrolled', window.scrollY > 40);
    window.addEventListener('scroll', onScroll, {passive:true});
    onScroll();
  }

  /* ---------- Mobile menu ---------- */
  const navToggle = document.getElementById('navToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileClose = document.getElementById('mobileClose');
  if(navToggle && mobileMenu){
    const close = ()=> mobileMenu.classList.remove('open');
    navToggle.addEventListener('click', ()=> mobileMenu.classList.add('open'));
    if(mobileClose) mobileClose.addEventListener('click', close);
    mobileMenu.querySelectorAll('a').forEach(a=> a.addEventListener('click', close));
    document.addEventListener('keydown', (e)=>{
      if(e.key === 'Escape' && mobileMenu.classList.contains('open')) close();
    });
  }

  /* ---------- Background particles ---------- */
  const particleContainer = document.getElementById('particles');
  if(particleContainer && !window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    for(let i = 0; i < 24; i++){
      const p = document.createElement('div');
      p.className = 'particle';
      p.style.left = Math.random()*100 + '%';
      p.style.top = Math.random()*100 + '%';
      p.style.animationDelay = (Math.random()*9) + 's';
      p.style.animationDuration = (7 + Math.random()*6) + 's';
      particleContainer.appendChild(p);
    }
  }
})();
